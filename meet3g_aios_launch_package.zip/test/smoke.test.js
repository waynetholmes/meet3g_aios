const test=require('node:test');const assert=require('node:assert');
test('package identity',()=>{const p=require('../package.json');assert.equal(p.name,'meet3g-aios');});
