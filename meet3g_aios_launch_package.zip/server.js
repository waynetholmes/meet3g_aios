const http = require('http');
const fs = require('fs');
const path = require('path');
const port = process.env.PORT || 3000;
const server = http.createServer((req,res)=>{
  if(req.url === '/health') {res.writeHead(200,{'Content-Type':'application/json'}); return res.end(JSON.stringify({status:'ok',service:'MEET3G AIOS'}));}
  const file = req.url === '/' ? 'index.html' : req.url.slice(1);
  const safe = path.normalize(file).replace(/^\.\.(\/|\\|$)/,'');
  fs.readFile(path.join(__dirname,'public',safe),(err,data)=>{
    if(err){res.writeHead(404);return res.end('Not found');}
    const ext=path.extname(safe); const types={'.html':'text/html','.css':'text/css','.js':'text/javascript'};
    res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream'});res.end(data);
  });
});
server.listen(port,()=>console.log(`MEET3G AIOS listening on ${port}`));
module.exports=server;
